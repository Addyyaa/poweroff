if [ ! `pidof reset_view` ]
then
kill -9 $(pgrep -f daemon.sh);
kill -9 $(pidof mymqtt); 
kill -9 $(pidof demo)
kill -9 $(pidof calender)
kill -9 $(pidof showNumber)
kill -9 $(pidof showGrayPicture)
kill -9 $(pidof clock)

if [ "`pidof ssplayer`" != "" ]; then
	/software/ssplayer_killer &
	count=0
	ssplayerDownCount=0
	while [ "$count" != "30"  ]
	do
		if [ "`pidof ssplayer`" == "" ]; then
			break
		fi
		count=$(($count+1))		
		
		if [ "$count" == "30" ] && [ "`pidof ssplayer`" != "" ]; then
			kill -9 $(pidof ssplayer)
			count=0
		fi
		sleep 0.1
	done
	
	sleep 0.1
fi

if [ "`pidof JpegPlayer`" == "" ]; then
	cd /upgrade/JpegPlayer/
	(./JpegPlayer --pic_path ./boot.jpg &); 
	sleep 2
fi

sleep 0.3
cd /upgrade/ota_view/release/bin
./reset_view &
fi
