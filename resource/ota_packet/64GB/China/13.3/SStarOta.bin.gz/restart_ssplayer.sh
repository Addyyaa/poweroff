LOCKFILE=/tmp/ssplayer.lock
{

if [ "`grep off /customer/screen_on_off`" != ""  ]; then
	echo "screen is off"
	exit 0
fi

echo high > /sys/class/gpio/gpio5/direction;

sleep 0.1

echo 50000 > /sys/class/pwm/pwmchip0/pwm0/duty_cycle; echo 500000 > /sys/class/pwm/pwmchip0/pwm0/duty_cycle;

sleep 0.1

if [ "`pidof demo`" != "" ]; then
	kill -9 $(pidof demo);
	
	if [ "`pidof demo`" != "" ]; then
		count=0
		while [ "$count" != "30"  ]
		do
			if [ "`pidof demo`" == "" ]; then
				break
			fi
			count=$(($count+1))
			sleep 0.1
		done
		
		sleep 0.1
	fi
fi

if [ "`pidof clock`" != "" ]; then
	kill -9 $(pidof clock);
	
	if [ "`pidof clock`" != "" ]; then
		count=0
		while [ "$count" != "30"  ]
		do
			if [ "`pidof clock`" == "" ]; then
				break
			fi
			count=$(($count+1))
			sleep 0.1
		done
		
		sleep 0.1
	fi
fi

if [ "`pidof calender`" != "" ]; then
	kill -9 $(pidof calender);
	
	if [ "`pidof calender`" != "" ]; then
		count=0
		while [ "$count" != "30"  ]
		do
			if [ "`pidof calender`" == "" ]; then
				break
			fi
			count=$(($count+1))
			sleep 0.1
		done
		
		sleep 0.1
	fi
fi

if [ "`pidof showNumber`" != "" ]; then
	kill -9 $(pidof showNumber);
	
	if [ "`pidof showNumber`" != "" ]; then
		count=0
		while [ "$count" != "30"  ]
		do
			if [ "`pidof showNumber`" == "" ]; then
				break
			fi
			count=$(($count+1))
			sleep 0.1
		done
		
		sleep 0.1
	fi
fi

if [ "`pidof showGrayPicture`" != "" ]; then
	kill -9 $(pidof showGrayPicture)
	
	if [ "`pidof showGrayPicture`" != "" ]; then
		count=0
		while [ "$count" != "30"  ]
		do
			if [ "`pidof showGrayPicture`" == "" ]; then
				break
			fi
			count=$(($count+1))
			sleep 0.1
		done
		
		sleep 0.1
	fi
fi



if [ "`pidof ssplayer`" != "" ]; then
echo "====================================restart_ssplayer.sh after kill ssplayer======================================================================"
cat /proc/mi_modules/mi_sys_mma/mma_heap_name0;
echo "===================================================================================================================================================="

	#kill -9 $(pidof ssplayer)	
	/software/ssplayer_killer &
	
	if [ "`pidof ssplayer`" != "" ]; then
		count=0
		while [ "$count" != "30"  ]
		do
			if [ "`pidof ssplayer`" == "" ]; then
				break
			fi
			count=$(($count+1))
			sleep 0.1
		done
		
		sleep 0.1
	fi
	
echo "====================================restart_ssplayer.sh after kill ssplayer======================================================================"
cat /proc/mi_modules/mi_sys_mma/mma_heap_name0;
echo "===================================================================================================================================================="
fi

echo "====================================restart_ssplayer.sh before kill JpegPlayer======================================================================"
cat /proc/mi_modules/mi_sys_mma/mma_heap_name0;
echo "===================================================================================================================================================="

if [ "`pidof JpegPlayer`" != "" ]; then
	/software/JpegPlayer_killer &
	#kill -9 $(pidof JpegPlayer);	
	if [ "`pidof JpegPlayer`" != "" ]; then
		count=0
		while [ "$count" != "30"  ]
		do
			if [ "`pidof JpegPlayer`" == "" ]; then
				break
			fi
			count=$(($count+1))
			if [ "$count" == "30"  ]; then
				kill -9 $(pidof JpegPlayer);
				sleep 1;
				break;
			fi
			sleep 0.1
		done
		
		sleep 0.1
	fi
fi

echo "====================================restart_ssplayer.sh after kill JpegPlayer======================================================================"
cat /proc/mi_modules/mi_sys_mma/mma_heap_name0;
echo "===================================================================================================================================================="


echo "====================================restart_ssplayer.sh before rm fb======================================================================"
cat /proc/mi_modules/mi_sys_mma/mma_heap_name0;
echo "=========================================================================================================================================="

echo high > /sys/class/gpio/gpio5/direction;

sleep 0.1

rmmod fbdev

sleep 1;

insmod /config/modules/4.9.84/fbdev.ko

sleep 1

#echo low > /sys/class/gpio/gpio5/direction; 

echo "====================================restart_ssplayer.sh after rm fb======================================================================"
cat /proc/mi_modules/mi_sys_mma/mma_heap_name0;
echo "========================================================================================================================================="




filename="/customer/config.ini"
section="screen"
key="luma_level"

value=$(awk -F "=" -v section="$section" -v key="$key" '$1 ~ /^\[/ && $1 ~ section {flag=1; next} flag==1 && $1 ~ /^\[/ {flag=0} flag==1 && $1 ~ key {print $2}' "$filename")
echo "luma_level = $value"
if [ "${value}" == "1" ]; then
	filename="/customer/luma_config.ini"
	section="luma_1"
	key="Luma"
	value=$(awk -F "=" -v section="$section" -v key="$key" '$1 ~ /^\[/ && $1 ~ section {flag=1; next} flag==1 && $1 ~ /^\[/ {flag=0} flag==1 && $1 ~ key {print $2}' "$filename")

elif [ "${value}" == "2" ]; then
	filename="/customer/luma_config.ini"
	section="luma_2"
	key="Luma"
	value=$(awk -F "=" -v section="$section" -v key="$key" '$1 ~ /^\[/ && $1 ~ section {flag=1; next} flag==1 && $1 ~ /^\[/ {flag=0} flag==1 && $1 ~ key {print $2}' "$filename")
elif [ "${value}" == "3" ]; then
	filename="/customer/luma_config.ini"
	section="luma_3"
	key="Luma"
	value=$(awk -F "=" -v section="$section" -v key="$key" '$1 ~ /^\[/ && $1 ~ section {flag=1; next} flag==1 && $1 ~ /^\[/ {flag=0} flag==1 && $1 ~ key {print $2}' "$filename")
fi

echo "luma = $value"

duty_cycle=$(($(($((100-$value))*500000))/100))
echo "duty_cycle = $duty_cycle"
#echo "$duty_cycle" > /sys/class/pwm/pwmchip0/pwm0/duty_cycle;



export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/lib:/software/ssplayer/lib
cd /software/ssplayer/;  


./ssplayer &
sleep 0.2 
echo low > /sys/class/gpio/gpio5/direction; 
sleep 0.1
echo "$duty_cycle" > /sys/class/pwm/pwmchip0/pwm0/duty_cycle;
} 200>$LOCKFILE

