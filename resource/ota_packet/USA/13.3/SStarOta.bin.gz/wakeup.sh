echo low > /sys/class/gpio/gpio5/direction; 
echo high > /sys/class/gpio/gpio69/direction;

sleep 1;

echo 'on' > /customer/screen_on_off

if [ ! `pidof JpegPlayer` ];
then 
export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/lib:/config/lib:/software/bluetooth/lib:/software/JpegPlayer/lib:/upgrade/JpegPlayer/lib:/config/wifi:/software/qrcode:/software/mqtt
cd /upgrade/JpegPlayer;  

(./JpegPlayer --pic_path ./boot.jpg &); 


sleep 1;

cd /software/
./launcher

fi; 

