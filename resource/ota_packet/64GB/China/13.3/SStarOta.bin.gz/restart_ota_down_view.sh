if [ ! `pidof ota_download` ]
then
kill -9 $(pgrep -f network_check.sh)
kill -9 $(pgrep -f daemon.sh);
kill -9 $(pidof mymqtt); 
kill -9 $(pidof demo)
kill -9 $(pidof calender)
kill -9 $(pidof showNumber)
kill -9 $(pidof showGrayPicture)
kill -9 $(pidof clock)

if [ "`pidof ssplayer`" != "" ]; then
	/software/ssplayer_killer &
	count=0
	ssplayerDownCount=0
	while [ "$count" != "30"  ]
	do
		if [ "`pidof ssplayer`" == "" ]; then
			break
		fi
		count=$(($count+1))
		
		ssplayer_state=$(top -n1 | grep ssplayer | grep -v grep | awk {'print $4'})
		if [ "$ssplayer_state" == "D" ]
		then
			ssplayerDownCount=$(($ssplayerDownCount+1))
			if [ "${ssplayerDownCount}" -eq "80" ]
			then
				ssplayerDownCount=0;					
				reboot
			fi
		else
			ssplayerDownCount=0;
		fi
		
		if [ "$count" == "30" ] && [ "`pidof ssplayer`" != "" ]; then
			kill -9 $(pidof ssplayer)
			count=0
		fi
		sleep 0.1
	done
	
	sleep 0.1
fi

if [ "`pidof JpegPlayer`" == "" ]; then
	cd /upgrade/JpegPlayer/
	(./JpegPlayer --pic_path ./boot.jpg &); 
	sleep 2
fi

sleep 0.3
cd /upgrade/ota_view/release/bin
./ota_download &
fi
