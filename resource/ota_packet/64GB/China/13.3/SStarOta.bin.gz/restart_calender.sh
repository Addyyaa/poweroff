LOCKFILE=/tmp/calender.lock

{
	echo 'restart calender'
	if [ "`grep off /customer/screen_on_off`" != ""  ]; then
		echo "screen is off"
		exit 0
	fi
	if [ "`pgrep -f restart_pintura.sh`" != "" ]; then
		kill -9 $(pgrep -f restart_pintura.sh)
	fi
	
	if [ "`pgrep -f restart_clock.sh`" != "" ]; then
		kill -9 $(pgrep -f restart_clock.sh)
	fi
	
	if [ "`pgrep -f restart_show_number.sh`" != "" ]; then
		kill -9 $(pgrep -f restart_show_number.sh)
	fi	
	
	if [ "`pidof showNumber`" != "" ]; then
		kill -9 $(pidof showNumber)
	fi
	
	if [ "`pidof clock`" != "" ]; then
		kill -9 $(pidof clock)
	fi
	
	if [ "`pidof demo`" != "" ]; then
		kill -9 $(pidof demo)
	fi
	
	if [ "`pidof showGrayPicture`" != "" ]; then
		kill -9 $(pidof showGrayPicture)
	fi
	
	find /tmp -type f -name "*.lock" -not -name "calender.lock" -delete
	
    # get lock
    flock -n 200
    if [ $? -ne 0 ]; then
		if [ "`pidof calender`" != "" ] && ([ "pidof showNumber" != "" ] || [ "pidof clock" != "" ] || [ "pidof demo" != "" ] || [ "pidof showGrayPicture" != "" ]) 
		then
			kill -9 $(pidof showNumber)
			kill -9 $(pidof clock)
			kill -9 $(pidof calender)
			kill -9 $(pidof showGrayPicture)
			kill -9 $(pidof demo)
			rm /tmp/*.lock
		elif [ "`pidof JpegPlayer`" != "" ] && [ "`pidof calender`" == "" ]
		then
			echo "JpegPlayer is running, but calender is not running, remove /tmp/calender.lock."
			if [ -e /tmp/calender.lock ]
			then
				rm /tmp/calender.lock
			fi
		else
			echo "Another instance of the script is running. Exiting."
			exit 1
		fi
    fi
	
echo "====================================restart_calender.sh before kill ssplayer==========================================================================="
cat /proc/mi_modules/mi_sys_mma/mma_heap_name0;
echo "======================================================================================================================================================="
	
	if [ "`pidof ssplayer`" != "" ]; then
		count=0
		ssplayerDownCount=0
		while [ "$count" != "30"  ]
		do
			if [ "`pidof ssplayer`" == "" ]; then
				break
			fi
			count=$(($count+1))
			
			ssplayer_state=$(top -n1 | grep ssplayer | grep -v grep | awk {'print $4'})
			if [ "$ssplayer_state" == "D" ]
			then
				ssplayerDownCount=$(($ssplayerDownCount+1))
				if [ "${ssplayerDownCount}" -eq "80" ]
				then
					ssplayerDownCount=0;					
					reboot
				fi
			else
				ssplayerDownCount=0;
			fi
			
			if [ "$count" == "30" ] && [ "`pidof ssplayer`" != "" ]; then
				kill -9 $(pidof ssplayer)
				count=0
			fi
			sleep 0.1
		done
		
		sleep 0.1
	fi
	
echo "====================================restart_calender.sh after kill ssplayer==========================================================================="
cat /proc/mi_modules/mi_sys_mma/mma_heap_name0;
echo "======================================================================================================================================================="
	
	if [ "`pidof JpegPlayer`" == "" ] && ([ ! -e /customer/screen_on_off ] || [ "`grep off /customer/screen_on_off`" == "" ]); then
		cd /upgrade/JpegPlayer/
		(./JpegPlayer --pic_path ./boot.jpg &); 
		count=0
		while [ "$count" != "20"  ]
		do
			if [ "`pidof JpegPlayer`" != "" ]; then
				break
			fi
			count=$(($count+1))
			sleep 0.1
		done
		sleep 0.1
	fi

    # run command
    if [ ! `pidof calender` ] && [ "`pidof JpegPlayer`" != "" ]; then
		
		count=0
		while [ "$count" != "20"  ]
		do
			if [ "`pidof showNumber`" == "" ] && [ "`pidof clock`" == "" ] && [ "`pidof demo`" == "" ] && [ "`pidof showGrayPicture`" == "" ]; then
				break;
			fi
			
			if [ "`pidof showNumber`" != "" ]; then
				kill -9 $(pidof showNumber)
			fi
			
			if [ "`pidof clock`" != "" ]; then
				kill -9 $(pidof clock)
			fi
			
			if [ "`pidof demo`" != "" ]; then
				kill -9 $(pidof demo)
			fi
			
			if [ "`pidof showGrayPicture`" != "" ]; then
				kill -9 $(pidof showGrayPicture)
			fi
			
			count=$(($count+1))
		done

		sleep 0.5
        cd /software/pintura/release/bin
        ./calender &
    fi
	find /tmp -type f -name "*.lock" -not -name "calender.lock" -delete
} 200>$LOCKFILE