for file in `ls /customer/picture `       	
do
    if [ -f /customer/picture"/"$file ] && [ "`grep "$file" /customer/picture_config.ini`" == "" ] && [ "$file" != "qrcode.png" ]
    then
        rm /customer/picture"/"$file	
    fi
done

if mountpoint -q "/mnt"; then 
for file in `ls /mnt/picture `       	
do
    if [ -f /mnt/picture"/"$file ] && [ "`grep "$file" /customer/picture_config.ini`" == "" ] && [ "$file" != "qrcode.png" ]
    then
        rm /mnt/picture"/"$file	
    fi
done
fi