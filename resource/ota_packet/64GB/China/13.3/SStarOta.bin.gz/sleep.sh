echo 'off' > /customer/screen_on_off
echo 50000 > /sys/class/pwm/pwmchip0/pwm0/duty_cycle; echo 500000 > /sys/class/pwm/pwmchip0/pwm0/duty_cycle;

sleep 0.01

if [ "`pgrep -f restart_pintura.sh`" != "" ]
then
	kill -9 $(pgrep -f restart_pintura.sh)
fi

if [ "`pgrep -f restart_clock.sh`" != "" ]
then
	kill -9 $(pgrep -f restart_clock.sh)
fi

if [ "`pgrep -f restart_calender.sh`" != "" ]
then
	kill -9 $(pgrep -f restart_calender.sh)
fi

if [ "`pgrep -f restart_show_number.sh`" != "" ]
then
	kill -9 $(pgrep -f restart_show_number.sh)
fi

if [ "`pgrep -f restart_ssplayer.sh`" != "" ]
then
	kill -9 $(pgrep -f restart_ssplayer.sh)
fi

if [ "`pidof JpegPlayer`" != "" ]
then
	/software/JpegPlayer_killer &
	count=0
	while [ "$count" != "30"  ]
	do
		if [ "`pidof JpegPlayer`" == "" ]; then
			break
		fi
		count=$(($count+1))
		sleep 0.1
	done
	if [ "`pidof JpegPlayer`" != "" ]; then
		kill -9 $(pidof JpegPlayer);
	fi
fi

if [ "`pidof demo`" != "" ]
then
	kill -9 $(pidof demo);
fi

if [ "`pidof clock`" != "" ]
then
	kill -9 $(pidof clock);
fi

if [ "`pidof calender`" != "" ]
then
	kill -9 $(pidof calender);
fi

if [ "`pidof showNumber`" != "" ]
then
	kill -9 $(pidof showNumber);
fi

if [ "`pidof showGrayPicture`" != "" ]
then
	kill -9 $(pidof showGrayPicture)
fi

if [ "`pidof ssplayer`" != "" ]
then
	/software/ssplayer_killer &
	count=0
	while [ "$count" != "30"  ]
	do
		if [ "`pidof ssplayer`" == "" ]; then
			break
		fi
		count=$(($count+1))
		sleep 0.1
	done
	
	if [ "`pidof ssplayer`" != "" ]
	then
		kill -9 $(pidof ssplayer)
	fi
fi

sleep 0.2


echo high > /sys/class/gpio/gpio5/direction;
echo low > /sys/class/gpio/gpio69/direction;

sleep 0.5;

rmmod fbdev

sleep 1;

insmod /config/modules/4.9.84/fbdev.ko

sleep 0.01;

