kill -9 $(pidof rtl_gatts)

cd /customer/bluetooth/bin
./hciconfig hci0 down

./hciconfig hci0 up
./hciconfig hci0 piscan

cd /software/bluetooth/bin
./rtl_gatts &

if [ "$1" == "notip" ];
then
echo "bluetooth_on no tip"
else
echo "bluetooth_on" > /upgrade/reset_status
fi

touch /customer/bluetooth_on
sync

