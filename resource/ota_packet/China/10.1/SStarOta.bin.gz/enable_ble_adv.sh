cd /customer/bluetooth/bin
./hciconfig hci0 leadv

