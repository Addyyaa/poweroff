kill -9 $(pgrep -f network_check.sh)
kill -9 $(pgrep -f daemon.sh)
kill -9 $(pidof mymqtt)
kill -9 $(pidof demo)
kill -9 $(pidof calender)
kill -9 $(pidof showNumber)
kill -9 $(pidof showGrayPicture)
kill -9 $(pidof clock)
kill -9 $(pidof rtl_gatts);
kill -9 $(pidof uart_main);


rm -rf /software/*
(tar tvf /upgrade/SStarOta.bin.gz) > /upgrade/tfilelist
(tar xvf /upgrade/SStarOta.bin.gz -C /software/) > /upgrade/xfilelist

sync

echo 'success' > /upgrade/ota_status


sleep 3

echo 50000 > /sys/class/pwm/pwmchip0/pwm0/duty_cycle; echo 500000 > /sys/class/pwm/pwmchip0/pwm0/duty_cycle;

sleep 0.01

kill -9 $(pidof JpegPlayer);

sleep 0.2

echo high > /sys/class/gpio/gpio5/direction;

reboot
#cd /upgrade/
#./otaunpack -x SStarOta.bin.gz -p upgrade.jpg