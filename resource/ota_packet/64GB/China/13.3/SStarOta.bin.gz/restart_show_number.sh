LOCKFILE=/tmp/showNumber.lock

{
	echo 'restart show number'
	if [ "`grep off /customer/screen_on_off`" != ""  ]; then
		echo "screen is off"
		exit 0
	fi
	if [ "`pgrep -f restart_pintura.sh`" != "" ]; then
		kill -9 $(pgrep -f restart_pintura.sh)
	fi
	
	if [ "`pgrep -f restart_clock.sh`" != "" ]; then
		kill -9 $(pgrep -f restart_clock.sh)
	fi
	
	if [ "`pgrep -f restart_calender.sh`" != "" ]; then
		kill -9 $(pgrep -f restart_calender.sh)
	fi	
	
	if [ "`pidof demo`" != "" ]; then
		kill -9 $(pidof demo)
	fi
	
	if [ "`pidof clock`" != "" ]; then
		kill -9 $(pidof clock)
	fi
	
	if [ "`pidof calender`" != "" ]; then
		kill -9 $(pidof calender)
	fi
	
	if [ "`pidof showGrayPicture`" != "" ]; then
		kill -9 $(pidof showGrayPicture)
	fi
	
	find /tmp -type f -name "*.lock" -not -name "showNumber.lock" -delete
	
    # get lock
    flock -n 200
    if [ $? -ne 0 ]; then
		if [ "`pidof showNumber`" != "" ] && ([ "pidof demo" != "" ] || [ "pidof clock" != "" ] || [ "pidof calender" != "" ] || [ "pidof showGrayPicture" != "" ]) 
		then
			kill -9 $(pidof showNumber)
			kill -9 $(pidof clock)
			kill -9 $(pidof calender)
			kill -9 $(pidof showGrayPicture)
			kill -9 $(pidof demo)
			rm /tmp/*.lock
		elif [ "`pidof JpegPlayer`" != "" ] && [ "`pidof showNumber`" == "" ]
		then
			echo "JpegPlayer is running, but showNumber is not running, remove /tmp/showNumber.lock."
			if [ -e /tmp/showNumber.lock ]
			then
				rm /tmp/showNumber.lock
			fi
		else
			echo "Another instance of the script is running. Exiting."
			exit 1
		fi
    fi
	
echo "====================================restart_show_number.sh before kill ssplayer======================================================================"
cat /proc/mi_modules/mi_sys_mma/mma_heap_name0;
echo "===================================================================================================================================================="
	
	if [ "`pidof ssplayer`" != "" ]; then

		count=0
		ssplayerDownCount=0
		while [ "$count" != "30"  ]
		do
			if [ "`pidof ssplayer`" == "" ]; then
				break
			fi
			count=$(($count+1))
			
			ssplayer_state=$(top -n1 | grep ssplayer | grep -v grep | awk {'print $4'})
			if [ "$ssplayer_state" == "D" ]
			then
				ssplayerDownCount=$(($ssplayerDownCount+1))
				if [ "${ssplayerDownCount}" -eq "80" ]
				then
					ssplayerDownCount=0;					
					reboot
				fi
			else
				ssplayerDownCount=0;
			fi
			
			if [ "$count" == "30" ] && [ "`pidof ssplayer`" != "" ]; then
				kill -9 $(pidof ssplayer)
				count=0
			fi
			sleep 0.1
		done
		
		sleep 0.1
	fi

echo "====================================restart_show_number.sh after kill ssplayer========================================================================="
cat /proc/mi_modules/mi_sys_mma/mma_heap_name0;
echo "===================================================================================================================================================="
	
	if [ "`pidof JpegPlayer`" == "" ] && ([ ! -e /customer/screen_on_off ] || [ "`grep off /customer/screen_on_off`" == "" ]); then
		cd /upgrade/JpegPlayer/
		(./JpegPlayer --pic_path ./boot.jpg &); 
		count=0
		while [ "$count" != "20"  ]
		do
			if [ "`pidof JpegPlayer`" != "" ]; then
				break
			fi
			count=$(($count+1))
			sleep 0.1
		done
		sleep 0.5
	fi

    # run command
    if [ ! `pidof showNumber` ] && [ "`pidof JpegPlayer`" != "" ]; then
		
		count=0
		while [ "$count" != "20"  ]
		do
			if [ "`pidof demo`" == "" ] && [ "`pidof clock`" == "" ] && [ "`pidof calender`" == "" ] && [ "`pidof showGrayPicture`" == "" ]; then
				break;
			fi
			
			if [ "`pidof demo`" != "" ]; then
				kill -9 $(pidof demo)
			fi
			
			if [ "`pidof clock`" != "" ]; then
				kill -9 $(pidof clock)
			fi
			
			if [ "`pidof calender`" != "" ]; then
				kill -9 $(pidof calender)
			fi
			
			if [ "`pidof showGrayPicture`" != "" ]; then
				kill -9 $(pidof showGrayPicture)
			fi
			
			count=$(($count+1))
		done

		sleep 0.3
        cd /software/pintura/release/bin
        ./showNumber &
    fi
	find /tmp -type f -name "*.lock" -not -name "showNumber.lock" -delete
} 200>$LOCKFILE
