#!/bin/sh
data='mymqtt'
pressTimeCount=0
pressTime=0
wlanDownCount=0
processDownCount=0
ssplayerDownCount=0
clockCount=0
currentProcess=0;
pairing_status='';
ble_state=0;
ble_state_update_time=0;
ble_state_count=0
ble_adv_count=0
show_video_logo_count=0
wlanHasUp=0
logName="/upgrade/daemon.log"  # log path

tipCount=0;

picture_update_file_path="/tmp/set_image_flag"
last_picture_update_time=0;

minute_update_file_path="/tmp/clock_minute_update"
last_minute_update_time=0;
let maxsize=1*1024*1024 	# 1 MB

daemon_log() {
	echo "$1"
	filesize=`ls -l $logName |awk '{print $5}'`
	if [ "$filesize" -ge "$maxsize" ]
	then
		echo > $logName
	fi
	printTime=$(date +%Y%m%d-%H:%M:%S)
	echo -e "$printTime $1 \n" >> $logName
}

grace_reboot() {
	daemon_log "$1, reboot"
	echo high > /sys/class/gpio/gpio5/direction;
	sleep 0.1
	if [ ! -e /sys/class/gpio/gpio48/value ]
	then				
		echo 48 > /sys/class/gpio/export				
	fi
	if [ -e /sys/class/gpio/gpio48/value ]
	then
		echo low > /sys/class/gpio/gpio48/direction
	fi
	sleep 0.1
	reboot
}

while [ 1 ]
    do
	if [ "`pidof demo`" != "" ] && [ -e /tmp/tip_tag ]; then
		tipCount=$(($tipCount+1))
		if [ $tipCount -gt 10 ]; then
			tipCount=0
			rm /tmp/tip_tag
			
			if [ "`pidof demo`" != "" ]; then			
				kill -9 $(pidof demo)
			fi
			touch /software/restart_pintura_flag
		fi
	fi
	if [ "`pidof clock`" != "" ] && [ -e $minute_update_file_path ]
	then
		mtime=$(stat -c %Y $minute_update_file_path)
		if [ $last_minute_update_time -eq 0 ]
		then
			last_minute_update_time=$mtime
			clockCount=0
		else
			if [ $last_minute_update_time -eq $mtime ]
			then
				clockCount=$(($clockCount+1))	
				if [ "$clockCount" == "62" ]
				then
					clockCount=0
					last_minute_update_time=$mtime
					kill $(pidof clock) 
					rm $minute_update_file_path
					touch /software/restart_clock_flag
				fi
			else
				last_minute_update_time=$mtime
				clockCount=0
			fi
		fi		
	else
		last_minute_update_time=0;
		clockCount=0
	fi
	if [ "`ifconfig | grep 'inet addr:'`" == "" ] && ([ ! -e /customer/pairing_status ] || [ `cat /customer/pairing_status | grep success` ]);
	then
		wlanDownCount=$(($wlanDownCount+1))
		if [ $wlanDownCount -eq 120 ]
		then
			wlanHasUp=0
			wlanDownCount=0
			
			if [ -e /customer/pairing_status ] && [ `cat /customer/pairing_status | grep success` ] && [ ! -e /tmp/net_unstable_tip_flag ]; then
				touch /tmp/net_unstable_tip_flag
				echo "network_instability_tip" > /upgrade/reset_status
				#if [ "`pidof ssplayer`" != "" ]
				#then					
				#	/software/ssplayer_killer &
				#	/software/restart_show_number.sh &
				#fi
			fi
			
			/software/restart_wifi.sh &
		fi
	fi
	
	ble_need_restart=0
	if [ -e /customer/blestate ] && [ "`pidof rtl_gatts`" != "" ]
	then		
		tmp_ble_state=$(cat /customer/blestate)
		tmp_ble_state_update_time=$(stat -c %Y /customer/blestate)
		if [ "$tmp_ble_state" != "" ] && [ "$tmp_ble_state" != "2" ] && [ "$tmp_ble_state" != "0" ] && [ "$tmp_ble_state" == "$ble_state" ] && [ "$tmp_ble_state_update_time" == "$ble_state_update_time" ]
		then
			ble_state_count=$(($ble_state_count+1))
			if [ "$tmp_ble_state" == "5" ]
			then
				if [ "$ble_state_count" == "90" ]
				then
					ble_need_restart=1
				fi
			else
				if [ "$ble_state_count" == "10" ]
				then
					ble_need_restart=1
				fi
			fi
		else
			ble_state=$tmp_ble_state
			ble_state_update_time=$tmp_ble_state_update_time
			ble_state_count=0;
		fi
		
		if [ "`pidof rtl_gatts`" != "" ] && [ "$tmp_ble_state" == "2" ]
		then
			ble_adv_count=$(($ble_adv_count+1))
			if [ "$ble_adv_count" == "3" ]
			then
				ble_adv_count=0
				if [ "`pgrep -f enable_ble_adv.sh`" != "" ]; then
					/software/enable_ble_adv.sh &
				else
					kill -9 $(pgrep -f enable_ble_adv.sh)
				fi
			fi
		else
			ble_adv_count=0;
		fi
	fi
	
	if [ "$ble_need_restart" == "1"  ]
	then
		ble_state_count=0;
		echo > /customer/blestate
		if [ "`pidof rtl_gatts`" == "" ]
		then			
			/software/restart_bluetooth.sh notip &
		else
			/software/disconnect_ble.sh &
		fi
	fi
	
	if [ "`grep off /customer/screen_on_off`" == ""  ] && [ -e /software/show_video_logo ] && [ "`pidof ssplayer`" == "" ] && [ "`pidof showGrayPicture`" == "" ];
	then
            show_video_logo_count=$(($show_video_logo_count+1))
            if [ $show_video_logo_count -eq 3 ]
            then
				show_video_logo_count=0
	            rm /software/show_video_logo
	            /software/showGrayPicture.sh &
	        fi
	else
		show_video_logo_count=0		
	fi
	
	if [ "`grep off /customer/screen_on_off`" == ""  ] && [ "`pidof JpegPlayer`" == "" ]; then
		if [ "`pidof demo`" != "" ]; then
			kill -9 $(pidof demo)
			processDownCount=0
		fi
		if [ "`pidof clock`" != "" ]; then
			kill -9 $(pidof clock)
			processDownCount=0
		fi
		if [ "`pidof calender`" != "" ]; then
			kill -9 $(pidof calender)
			processDownCount=0
		fi
		if [ "`pidof showNumber`" != "" ]; then
			kill -9 $(pidof showNumber)
			processDownCount=0
		fi
		if [ "`pidof showGrayPicture`" != "" ]; then
			kill -9 $(pidof showGrayPicture)
			processDownCount=0
		fi
	fi	
	
	if [ "`grep off /customer/screen_on_off`" == ""  ] && [ "`pidof showGrayPicture`" == "" ] && [ "`pgrep -f showGrayPicture.sh`" == "" ] && [ -e /tmp/software_init_finish ]
    then
		
		filename="/customer/config.ini"
		section="screen"
		key="display_type"
		display_mode_key="display_mode"
		loop_time_key="loop_time"
	
		value=$(awk -F "=" -v section="$section" -v key="$key" '$1 ~ /^\[/ && $1 ~ section {flag=1; next} flag==1 && $1 ~ /^\[/ {flag=0} flag==1 && $1 ~ key {print $2}' "$filename")
		display_mode=$(awk -F "=" -v section="$section" -v key="$display_mode_key" '$1 ~ /^\[/ && $1 ~ section {flag=1; next} flag==1 && $1 ~ /^\[/ {flag=0} flag==1 && $1 == key {print $2}' "$filename")
		loop_time=$(awk -F "=" -v section="$section" -v key="$loop_time_key" '$1 ~ /^\[/ && $1 ~ section {flag=1; next} flag==1 && $1 ~ /^\[/ {flag=0} flag==1 && $1 ~ key {print $2}' "$filename")
		
		if [ "${currentProcess}" == "0" ]
		then
			currentProcess=$value
		fi
		
		if [ "${value}" == "3" ]
		then
			if [ "${value}" == "${currentProcess}" ] && [ "`pidof clock`" == "" ]
			then
				processDownCount=$(($processDownCount+1))
			else
				currentProcess=$value
				processDownCount=0
			fi
			
			if [ $processDownCount -ge 2 ] || [ -e /software/restart_clock_flag ]
			then
				if [ -e /software/restart_clock_flag ]; then
					rm /software/restart_clock_flag;
				fi
				processDownCount=0
				if [ "`pgrep -f restart_clock.sh`" == "" ] && [ "`pidof clock`" == "" ]; then
					/software/restart_clock.sh &
				fi
			fi
		elif [ "${value}" == "4" ]
		then
			if [ "${value}" == "${currentProcess}" ] && [ "`pidof calender`" == "" ]
			then
				processDownCount=$(($processDownCount+1))
			else
				currentProcess=$value
				processDownCount=0
			fi
			
			if [ $processDownCount -ge 2 ]
			then			
				processDownCount=0
				if [ "`pgrep -f restart_calender.sh`" == "" ] && [ "`pidof calender`" == "" ]; then
					/software/restart_calender.sh &
				fi
			fi
		elif [ "${value}" == "5" ]
		then
			if [ "${value}" == "${currentProcess}" ] && [ "`pidof showNumber`" == "" ]
			then
				processDownCount=$(($processDownCount+1))
			else
				currentProcess=$value
				processDownCount=0
			fi
			
			if [ $processDownCount -ge 2 ]
			then			
				processDownCount=0
				if [ "`pgrep -f restart_show_number.sh`" == "" ] && [ "`pidof showNumber`" == "" ]; then
					/software/restart_show_number.sh &
				fi
			fi
		elif [ "${value}" == "1" ] || [ "${value}" == "2" ] || [ "${value}" == "6" ]
		then
			if [ "${value}" == "${currentProcess}" ] && [ "`pidof demo`" == "" ]
			then
				processDownCount=$(($processDownCount+1))
			else
				currentProcess=$value
				processDownCount=0
			fi
			
			
			if [ $processDownCount -ge 2 ] || [ -e /software/restart_pintura_flag ]
			then	
				if [ -e /software/restart_pintura_flag ]; then
					rm /software/restart_pintura_flag;
				fi
				processDownCount=0
				if [ "`pgrep -f restart_pintura.sh`" == "" ] && [ "`pidof demo`" == "" ]; then
					/software/restart_pintura.sh &
				fi
			fi	
		elif [ "${value}" == "7" ] || [ "${value}" == "8" ] || [ "${value}" == "9" ]
		then
			if [ "${value}" == "${currentProcess}" ] && [ "`pidof ssplayer`" == "" ] && [ "`cat /sys/class/gpio/gpio71/value | grep 0`" == "" ]
			then
				processDownCount=$(($processDownCount+1))
			else
				currentProcess=$value
				processDownCount=0
			fi
			
			if [ $processDownCount -ge 5 ]
			then	
				processDownCount=0
				if [ "`pgrep -f restart_ssplayer.sh`" == "" ] && [ "`pidof ssplayer`" == "" ] && [ ! -e /software/show_video_logo ]; then
					video_config_count=$(ls /customer/video_config* 2>/dev/null | wc -l)
					if [ $video_config_count -gt 0 ]; then
						/software/restart_ssplayer.sh &
					elif [ "`pidof showGrayPicture`" == "" ]; then
						/software/showGrayPicture.sh &
					fi
				fi
			fi
		fi
	else
		processDownCount=0
	fi
	
    if [ "`pidof mymqtt`" == "" ] && [ "`ifconfig | grep 'inet addr:'`" != "" ] && [ `cat /sys/class/net/wlan0/operstate | grep up` ]
    then
	   if [ ! -e /customer/pairing_status ] || [ `cat /customer/pairing_status | grep success` ]
	   then
			wlanHasUp=1
			/software/mqtt/mymqtt &
			kill -9 $(pidof ntpd)			
			
			filename="/software/local.ini"
			section="local"
			key="local"
	
			value=$(awk -F "=" -v section="$section" -v key="$key" '$1 ~ /^\[/ && $1 ~ section {flag=1; next} flag==1 && $1 ~ /^\[/ {flag=0} flag==1 && $1 ~ key {print $2}' "$filename")
			if [ "${value}" == "1" ]; then
				echo "ntpd -p ntp.aliyun.com"
				ntpd -p ntp.aliyun.com &
			else
				echo "ntpd -p time.nist.gov"
				ntpd -p time.nist.gov &
			fi
	   fi
    fi
	
	if [ "`pidof set_play_mode`" == "" ] && [ "`pidof mymqtt`" != "" ]
	then
		/software/set_play_mode &
	fi
	
	no_wakeup_count=$(dmesg | grep 'no wakeup event' | wc -l)
	if [ "$no_wakeup_count" -gt 0 ]; then 
		grace_reboot "dmesg catch no wakeup event"
	fi
	
	if [ "`pidof ssplayer`" != "" ]; then		
		ssplayer_state=$(top -n1 | grep ssplayer | grep -v grep | grep -v tail  | grep -v cat | awk {'print $4'})
		if [ "$ssplayer_state" == "D" ]
		then
			ssplayerDownCount=$(($ssplayerDownCount+1))
			if [ $ssplayerDownCount -eq 20 ]
			then
				ssplayerDownCount=0;
				grace_reboot "top -n1 catch ssplayer D status over 20 times"
			fi
		else
			ssplayerDownCount=0;
		fi
	fi
	
	if [ ! -e /sys/class/gpio/gpio71/value ]
	then
		#reset gpio, cat /sys/class/gpio/gpio71/value 1:normal 0: press
		echo 71 > /sys/class/gpio/export
	fi
	
	if [ "`cat /sys/class/gpio/gpio71/value | grep 0`" != "" ]
	then
		pressTimeCount=$(($pressTimeCount+1))
		currentTime=$(date +%s)
		if [ $pressTime -eq 0 ]
		then
			pressTime=$currentTime
		fi
		
		time_difference=$((currentTime - pressTime)) 
		
		
		if [ $pressTimeCount -eq 1 ]
		then						
			daemon_log "short press restart bluetooth"
			
			echo "short press restart bluetooth"
			/software/restart_bluetooth.sh &
			if [ "`pidof ssplayer`" != "" ]
			then
				/software/ssplayer_killer &				
				/software/restart_show_number.sh &
			fi
		fi
		
		if [ $pressTimeCount -eq 5 ] || ([ $pressTime -ne 0 ] && [ $time_difference -ge 5 ] && [ $time_difference -lt 10 ] && (! grep -q  "system_reset_tip" /upgrade/reset_status))
		then			
			echo "system_reset_tip" > /upgrade/reset_status
			if [ "`pidof ssplayer`" != "" ]
			then				
				/software/ssplayer_killer &				
				/software/restart_show_number.sh &
				processDownCount=0
			fi
		fi
		
		if [ $pressTimeCount -ge 5 ]
		then
			processDownCount=0
		fi
		
		if [ $pressTimeCount -eq 10 ] || ([ $pressTime -ne 0 ] && [ $time_difference -ge 10 ] && [ $time_difference -lt 30 ] )
		then			
			daemon_log "long press recover system, time_difference=$time_difference"
			/upgrade/restore_factory_settings.sh &
			processDownCount=0
		fi
					
	else
		
		pressTimeCount=0
		pressTime=0
		currentTime=0
	fi
		
    sleep 1
done
