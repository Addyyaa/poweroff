kill -9 $(pgrep -f network_check.sh)
kill -9 $(pgrep -f daemon.sh)
kill -9 $(pidof mymqtt)
kill -9 $(pidof demo)
kill -9 $(pidof calender)
kill -9 $(pidof showNumber)
kill -9 $(pidof showGrayPicture)
kill -9 $(pidof clock)
kill -9 $(pidof rtl_gatts);
kill -9 $(pidof uart_main);

if [ -e /upgrade/update_reset ] && [ -e /upgrade/SStarOta.bin.gz ]; then
	cp /upgrade/SStarOta.bin.gz /upgrade/restore/SStarOta.bin.gz
fi

rm -rf /software/*
(tar tvf /upgrade/SStarOta.bin.gz) > /upgrade/tfilelist
(tar xvf /upgrade/SStarOta.bin.gz -C /software/) > /upgrade/xfilelist

sync

echo 'success' > /upgrade/ota_status

if [ -e /upgrade/update_reset ]; then	
	return
fi



sleep 3

echo 50000 > /sys/class/pwm/pwmchip0/pwm0/duty_cycle; echo 500000 > /sys/class/pwm/pwmchip0/pwm0/duty_cycle;

sleep 0.01

kill -9 $(pidof JpegPlayer);

sleep 0.2

echo high > /sys/class/gpio/gpio5/direction;

#reset gpio 48, reset screen
if [ ! -e /sys/class/gpio/gpio48/value ]
then				
	echo 48 > /sys/class/gpio/export				
fi
if [ -e /sys/class/gpio/gpio48/value ]
then
	echo low > /sys/class/gpio/gpio48/direction
fi

reboot
#cd /upgrade/
#./otaunpack -x SStarOta.bin.gz -p upgrade.jpg