echo '' > /upgrade/tfilelist; 
echo '' > /upgrade/xfilelist;
if [ -e /tmp/software_init_finish ]; then
	rm /tmp/software_init_finish;
fi
echo 'upgrading' > /upgrade/ota_status
kill -9 $(pgrep -f network_check.sh)
kill -9 $(pgrep -f daemon.sh)
kill -9 $(pidof mymqtt)
kill -9 $(pidof demo)
kill -9 $(pidof calender)
kill -9 $(pidof showNumber)
kill -9 $(pidof showGrayPicture)
kill -9 $(pidof clock)
kill -9 $(pidof rtl_gatts);
kill -9 $(pidof uart_main);

if [ "`pidof ssplayer`" != "" ]; then
	kill -9 $(pidof ssplayer)		
	if [ "`pidof JpegPlayer`" != "" ]; then
		kill -9 $(pidof JpegPlayer)
	fi	
	sleep 0.2
fi

if [ "`pidof JpegPlayer`" == "" ]; then
	cd /upgrade/JpegPlayer/
	(./JpegPlayer --pic_path ./boot.jpg &); 
	sleep 2
fi

/upgrade/restart_reset_view.sh &

rm -rf /customer/picture/
rm -rf /customer/picture_cache/

rm -rf /customer/video/*

cp /customer/config.ini_bak /customer/config.ini
cp /customer/wpa_supplicant.conf_bak /appconfigs/wpa_supplicant.conf
cp /customer/groupId.ini_bak /customer/groupId.ini


rm /customer/video_config*.ini
rm /customer/picture_config*.ini
rm /customer/pairing_status;
rm /customer/picture_total_config.ini
rm /customer/video_total_config.ini

cp /customer/picture_total_config.ini_bak /customer/picture_total_config.ini
cp /customer/video_total_config.ini_bak /customer/video_total_config.ini

if [ -e /mnt/picture/ ]; then
	rm -rf /mnt/picture/*
fi

if [ -e /mnt/video/ ]; then
	rm -rf /mnt/video/*
fi

if [ -e /mnt/backup/ ]; then
	for file in /mnt/backup/*; do
		if [[ -f "$file" ]]; then
			extension="${file##*.}" 
			if [[ "$extension" == "jpg" ]]; then
				cp "$file" "/mnt/picture/"
			elif  [[ "$extension" == "mp4" ]]; then
				cp "$file" "/mnt/video/"
			fi
		fi
	done
	
	if [ -e /mnt/backup/config.ini ]; then
		cp /mnt/backup/config.ini /customer/config.ini
	fi
	
	if [ -e /mnt/backup/picture_config.ini ]; then
		cp /mnt/backup/picture_config.ini /customer/picture_config.ini
	fi
	
	if [ -e /mnt/backup/video_config.ini ]; then
		cp /mnt/backup/video_config.ini /customer/video_config.ini
	fi
fi

rm -rf /software/*
(tar tvf /upgrade/restore/SStarOta.bin.gz) > /upgrade/tfilelist
(tar xvf /upgrade/restore/SStarOta.bin.gz -C /software/) > /upgrade/xfilelist

rm /software/luma_config.ini;

sync

echo 'success' > /upgrade/ota_status

sleep 3

echo high > /sys/class/gpio/gpio5/direction;
sleep 0.1

echo 50000 > /sys/class/pwm/pwmchip0/pwm0/duty_cycle; echo 500000 > /sys/class/pwm/pwmchip0/pwm0/duty_cycle;

sleep 0.01

kill -9 $(pidof JpegPlayer);

sleep 0.2



#reset gpio 48, reset screen
if [ ! -e /sys/class/gpio/gpio48/value ]
then				
	echo 48 > /sys/class/gpio/export				
fi
if [ -e /sys/class/gpio/gpio48/value ]
then
	echo low > /sys/class/gpio/gpio48/direction
fi

reboot
#sleep 0.5
#echo low > /sys/class/gpio/gpio5/direction;
#sleep 0.2;
#echo 0 > /sys/class/pwm/pwmchip0/pwm0/duty_cycle;
#sleep 0.2;
#cd /upgrade/
#./otaunpack -x /upgrade/restore/SStarOta.bin.gz -p /upgrade/upgrade.jpg



