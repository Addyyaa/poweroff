LOCKFILE=/tmp/demo.lock

{
	echo 'restart pintura'
	if [ "`grep off /customer/screen_on_off`" != ""  ]; then
		echo "screen is off"
		exit 0
	fi
	if [ "`pgrep -f restart_clock.sh`" != "" ]; then
		kill -9 $(pgrep -f restart_clock.sh)
	fi
	
	if [ "`pgrep -f restart_calender.sh`" != "" ]; then
		kill -9 $(pgrep -f restart_calender.sh)
	fi
	
	if [ "`pgrep -f restart_show_number.sh`" != "" ]; then
		kill -9 $(pgrep -f restart_show_number.sh)
	fi
	
	if [ "`pidof showNumber`" != "" ]; then
		kill -9 $(pidof showNumber)
	fi
	
	if [ "`pidof clock`" != "" ]; then
		kill -9 $(pidof clock)
	fi
	
	if [ "`pidof calender`" != "" ]; then
		kill -9 $(pidof calender)
	fi
	
	if [ "`pidof showGrayPicture`" != "" ]; then
		kill -9 $(pidof showGrayPicture)
	fi
	
	find /tmp -type f -name "*.lock" -not -name "demo.lock" -delete
	
    # get lock
    flock -n 200
    if [ $? -ne 0 ]; then
		if [ "`pidof demo`" != "" ] && ([ "pidof showNumber" != "" ] || [ "pidof clock" != "" ] || [ "pidof calender" != "" ] || [ "pidof showGrayPicture" != "" ]) 
		then
			kill -9 $(pidof showNumber)
			kill -9 $(pidof clock)
			kill -9 $(pidof calender)
			kill -9 $(pidof showGrayPicture)
			kill -9 $(pidof demo)
			rm /tmp/*.lock
		else
			echo "Another instance of the script is running. Exiting."
			exit 1
		fi
    fi	
	
	if [ "`pidof ssplayer`" != "" ]; then
		count=0
		while [ "$count" != "30"  ]
		do
			if [ "`pidof ssplayer`" == "" ]; then
				break
			fi
			count=$(($count+1))
			sleep 0.1
		done
		kill -9 $(pidof ssplayer)		
		if [ "`pidof JpegPlayer`" != "" ]; then
			kill -9 $(pidof JpegPlayer)
		fi	
		sleep 0.1
	fi
	
	if [ "`pidof JpegPlayer`" == "" ] && ([ ! -e /customer/screen_on_off ] || [ "`grep off /customer/screen_on_off`" == "" ]); then
		cd /upgrade/JpegPlayer/
		(./JpegPlayer --pic_path ./boot.jpg &); 
		count=0
		while [ "$count" != "20"  ]
		do
			if [ "`pidof JpegPlayer`" != "" ]; then
				break
			fi
			count=$(($count+1))
			sleep 0.1
		done
	fi

    # run command
    if [ ! `pidof demo` ] && [ "`pidof JpegPlayer`" != "" ]; then
		
		count=0
		while [ "$count" != "20"  ]
		do
			if [ "`pidof showNumber`" == "" ] && [ "`pidof clock`" == "" ] && [ "`pidof calender`" == "" ] && [ "`pidof showGrayPicture`" == "" ]; then
				break;
			fi
			
			if [ "`pidof showNumber`" != "" ]; then
				kill -9 $(pidof showNumber)
			fi
			
			if [ "`pidof clock`" != "" ]; then
				kill -9 $(pidof clock)
			fi
			
			if [ "`pidof calender`" != "" ]; then
				kill -9 $(pidof calender)
			fi
			
			if [ "`pidof showGrayPicture`" != "" ]; then
				kill -9 $(pidof showGrayPicture)
			fi
			
			count=$(($count+1))
		done

		sleep 0.4
        cd /software/pintura/release/bin
        ./demo &
    fi
	
} 200>$LOCKFILE
