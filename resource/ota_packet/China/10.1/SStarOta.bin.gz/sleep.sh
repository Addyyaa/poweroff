echo 50000 > /sys/class/pwm/pwmchip0/pwm0/duty_cycle; echo 500000 > /sys/class/pwm/pwmchip0/pwm0/duty_cycle;

sleep 0.01

kill -9 $(pidof JpegPlayer);

kill -9 $(pidof demo);

kill -9 $(pidof clock);

kill -9 $(pidof calender);

kill -9 $(pidof showNumber);

kill -9 $(pidof showGrayPicture)

kill -9 $(pidof ssplayer)

sleep 0.2


echo high > /sys/class/gpio/gpio5/direction;
echo low > /sys/class/gpio/gpio69/direction;

echo 'off' > /customer/screen_on_off

rmmod fbdev

sleep 0.01;

insmod /config/modules/4.9.84/fbdev.ko


