if [ ! `pidof ota_download` ]
then
kill -9 $(pgrep -f network_check.sh)
kill -9 $(pgrep -f daemon.sh);
kill -9 $(pidof mymqtt); 
kill -9 $(pidof demo)
kill -9 $(pidof calender)
kill -9 $(pidof showNumber)
kill -9 $(pidof showGrayPicture)
kill -9 $(pidof clock)

	if [ "`pidof ssplayer`" != "" ]; then
		kill -9 $(pidof ssplayer)		
		if [ "`pidof JpegPlayer`" != "" ]; then
			kill -9 $(pidof JpegPlayer)
		fi	
		sleep 0.2
	fi
	
	if [ "`pidof JpegPlayer`" == "" ]; then
		cd /upgrade/JpegPlayer/
		(./JpegPlayer --pic_path ./boot.jpg &); 
		sleep 2
	fi

sleep 0.3
cd /upgrade/ota_view/release/bin
./ota_download &
fi
