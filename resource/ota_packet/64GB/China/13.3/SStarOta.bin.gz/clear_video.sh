if [ "$#" -ne 1 ]; then  
    echo "Usage: $0 <timestamp>"  
    exit 1  
fi  

if [ "`pidof picture_downloader`" != "" ]; then
	kill -9 $(pidof picture_downloader);
fi

if [ "`pidof wget`" != "" ]; then
	kill -9 $(pidof wget);
fi

input_timestamp=$1  
  

directory="/customer/video_cache"    

find "$directory" -type f -name "*_*.mp4" | while read -r file; do  
    timestamp=$(basename "$file" | awk -F_ '{print $2}' | awk -F. '{print $1}') 
    if [ "$(printf '%d' "$timestamp")" -lt "$(printf '%d' "$input_timestamp")" ]; then  
        echo "Deleting $file"  
        rm "$file"  
    fi  
done  


directory="/customer/video"

find "$directory" -type f -name "*.mp4" | while read -r file; do  
    timestamp=$(basename "$file" | awk -F. '{print $1}') 
    if [ "$(printf '%d' "$timestamp")" -lt "$(printf '%d' "$input_timestamp")" ]; then  
        echo "Deleting $file"  
        rm "$file"  
    fi  
done 

if mountpoint -q \"/mnt\"; then
	directory="/mnt/video"
fi

find "$directory" -type f -name "*.mp4" | while read -r file; do  
    timestamp=$(basename "$file" | awk -F. '{print $1}') 
    if [ "$(printf '%d' "$timestamp")" -lt "$(printf '%d' "$input_timestamp")" ]; then  
        echo "Deleting $file"  
        rm "$file"  
    fi  
done 
  
echo "Files with timestamps earlier than $input_timestamp have been deleted."

if [ "`pidof picture_downloader`" == "" ]; then
	/software/picture_downloader &
fi