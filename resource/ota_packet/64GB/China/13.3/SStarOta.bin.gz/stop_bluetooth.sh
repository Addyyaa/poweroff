is_bluetooth_on=0
if [ `pidof rtl_gatts` ]; then
	is_bluetooth_on=1
	kill -9 $(pidof rtl_gatts)
fi

cd /customer/bluetooth/bin
./hciconfig hci0 down

if [ "$is_bluetooth_on" -eq "1" ]; then
	echo "bluetooth_off" > /upgrade/reset_status
fi

if [ -e /customer/bluetooth_on ]; then
	rm /customer/bluetooth_on
	sync
fi



