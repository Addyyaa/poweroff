if [ "`pgrep -f restart_pintura.sh`" != "" ]; then
	kill -9 $(pgrep -f restart_pintura.sh)
fi

if [ "`pgrep -f restart_clock.sh`" != "" ]; then
	kill -9 $(pgrep -f restart_clock.sh)
fi

if [ "`pgrep -f restart_calender.sh`" != "" ]; then
	kill -9 $(pgrep -f restart_calender.sh)
fi	
	
if [ "`pgrep -f restart_show_number.sh`" != "" ]; then
	kill -9 $(pgrep -f restart_show_number.sh)
fi

kill -9 $(pidof demo)
kill -9 $(pidof clock)
kill -9 $(pidof calender)
kill -9 $(pidof showNumber)
kill -9 $(pidof showGrayPicture)

if [ "`pidof ssplayer`" != "" ]; then
	kill -9 $(pidof ssplayer)		
	if [ "`pidof JpegPlayer`" != "" ]; then
		kill -9 $(pidof JpegPlayer)
	fi	
	sleep 0.2
fi

if [ "`pidof JpegPlayer`" == "" ]; then
	cd /upgrade/JpegPlayer/
	(./JpegPlayer --pic_path ./boot.jpg &); 
	count=0
	while [ "$count" != "20"  ]
	do
		if [ "`pidof JpegPlayer`" != "" ]; then
			break
		fi
		count=$(($count+1))
		sleep 0.1
	done
	sleep 1
fi

sleep 0.3
cd /software/pintura/release/bin
./showGrayPicture &