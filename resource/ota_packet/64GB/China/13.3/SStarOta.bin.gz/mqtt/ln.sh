current_path=$(pwd)
cd $current_path

if [ -f "$current_path/liblog4c.so" ] && [ ! -f "$current_path/liblog4c.so.3" ]; then
	ln -s liblog4c.so liblog4c.so.3
fi

if [ -f "$current_path/liblog4c.so" ] && [ ! -f "$current_path/liblog4c.so.3.3.1" ]; then
	ln -s liblog4c.so liblog4c.so.3.3.1
fi

if [ -f "$current_path/liblog4cpp.so" ] && [ ! -f "$current_path/liblog4cpp.so.5" ]; then
	ln -s liblog4cpp.so liblog4cpp.so.5
fi

if [ -f "$current_path/liblog4cpp.so" ] && [ ! -f "$current_path/liblog4cpp.so.5.0.6" ]; then
	ln -s liblog4cpp.so liblog4cpp.so.5.0.6
fi