if pidof picture_downloader > /dev/null; then
	kill -9 $(pidof picture_downloader);
fi

rm /customer/picture/*tmp
if [ -e /mnt/picture/ ]; then
	rm /mnt/picture/*tmp
fi

if pidof wget > /dev/null; then
	kill -9 $(pidof wget);
fi

if [ -e /customer/video_cache ]; then	
	timestamp=$(date +%s)	
	mv /customer/video_cache /customer/video_cache_trash_$timestamp
	mkdir -p /customer/video_cache/
	rm -rf /customer/video_cache_trash_$timestamp &	
fi

if [ -e /mnt/video/ ]; then
	timestamp=$(date +%s)	
	mv /mnt/video /mnt/video_trash_$timestamp
	mkdir -p /mnt/video/
	rm -rf /mnt/video_trash_$timestamp &
fi

if [ -e /customer/video/ ]; then
	timestamp=$(date +%s)	
	mv /customer/video /customer/video_trash_$timestamp
	mkdir -p /customer/video/
	rm -rf /customer/video_trash_$timestamp &
fi


sync

if ! pidof picture_downloader > /dev/null; then
	/software/picture_downloader &
fi