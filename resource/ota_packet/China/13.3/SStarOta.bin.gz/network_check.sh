#!/bin/sh

pressTimeCount=0
wlanDownCount=0
wlanHasUp=0

filename="/software/local.ini"
section="local"
key="local"


ip=""
value=$(awk -F "=" -v section="$section" -v key="$key" '$1 ~ /^\[/ && $1 ~ section {flag=1; next} flag==1 && $1 ~ /^\[/ {flag=0} flag==1 && $1 ~ key {print $2}' "$filename")
if [ "${value}" == "2" ]; then
	ip="cloud-service.austinelec.com"
elif [ "${value}" == "1" ]; then
	ip="cloud-service-us.austinelec.com"
fi

logName="/software/network_check.log"  # log path
let maxsize=1*1024*1024 	# 1 MB
while [ 1 ]
do	
	if [ ! -e /sys/class/net/wlan0/operstate ] || ([ `cat /sys/class/net/wlan0/operstate | grep down` ] && [ "$wlanHasUp" -eq "1" ])
	then
		wlanDownCount=$(($wlanDownCount+1))
		if [ "$wlanDownCount" -eq "60" ]
		then
			if [ "$filesize" -ge "$maxsize" ]
			then
				echo > $logName
			fi
			time="`date '+%Y-%m-%d %H:%M:%S'`"
			echo "$time, wlan status error, restart wifi" >> $logName
			wlanHasUp=0
			wlanDownCount=0
			
			/software/restart_wifi.sh &
		fi
	fi
	
    if [ ! `pidof mymqtt` ] && [ `cat /sys/class/net/wlan0/operstate | grep up` ] && [ "`ifconfig | grep 'inet addr:'`" != "" ]
    then
		sleep 1
	   wlanHasUp=1
       /software/mqtt/mymqtt &
	   kill $(pidof ntpd)
       ntpd -p ntp.aliyun.com &
		if [ "$filesize" -ge "$maxsize" ]
		then
			echo > $logName
		fi
		time="`date '+%Y-%m-%d %H:%M:%S'`"
		echo "$time, network up, restart mymqtt and ntpd" >> $logName
    fi
	
    sleep 1
done
