if pidof wget > /dev/null
then
	return
fi

for file in `ls /customer/picture `       	
do
	is_file_in_use=0;
	for ini_file in `ls /customer/picture_config*.ini`
	do
		if [ -f /customer/picture"/"$file ] && [ "`grep "$file" "$ini_file"`" != "" ]
		then
			if ! pidof wget > /dev/null
			then
				is_file_in_use=1
			fi
		fi
	done	
	
	if find /customer/picture_cache -maxdepth 1 -type f -name "*${file##*/}" 2>/dev/null  | grep -q .; then  
        is_file_in_use=1
    fi  
	
	
	if [ $is_file_in_use -eq 0 ];then
		if ! pidof wget > /dev/null
		then
			rm /customer/picture"/"$file	
		fi
	fi	
done

if mountpoint -q "/mnt"; then 
	for file in `ls /mnt/picture `       	
	do
		is_file_in_use=0;
		for ini_file in `ls /customer/picture_config*.ini`
		do
			if [ -f /mnt/picture"/"$file ] && [ "`grep "$file" "$ini_file"`" != "" ]
			then
				if ! pidof wget > /dev/null
				then
					is_file_in_use=1
				fi
			fi
		done
						
		if find /customer/picture_cache -maxdepth 1 -type f -name "*${file##*/}" 2>/dev/null  | grep -q .; then  
			is_file_in_use=1
		fi  
		
		if [ $is_file_in_use -eq 0 ];then
			if ! pidof wget > /dev/null
			then
				rm /mnt/picture"/"$file	
			fi
		fi	
	done
fi