#wifi enable
if [ ! `pidof rtl_gatts` ];
then
	echo 14 > /sys/class/gpio/export
	echo low > /sys/class/gpio/gpio14/direction
	sleep 0.5
	echo high > /sys/class/gpio/gpio14/direction
	sleep 5
fi

/config/wifi/restart_wifi.sh &

