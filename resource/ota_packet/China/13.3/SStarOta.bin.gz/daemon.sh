#!/bin/sh
data='mymqtt'
pressTimeCount=0
wlanDownCount=0
processDownCount=0
currentProcess=0;
pairing_status='';
ble_state=0;
ble_state_update_time=0;
ble_state_count=0
ble_adv_count=0
wlanHasUp=0
logName="/upgrade/daemon.log"  # log path
let maxsize=1*1024*1024 	# 1 MB
while [ 1 ]
    do
	
	if [ "`ifconfig | grep 'inet addr:'`" == "" ] && ([ ! -e /customer/pairing_status ] || [ `cat /customer/pairing_status | grep success` ]);
	then
		wlanDownCount=$(($wlanDownCount+1))
		if [ "$wlanDownCount" -eq "480" ]
		then
			wlanHasUp=0
			wlanDownCount=0
			
			/software/restart_wifi.sh &
		fi
	fi
	
	ble_need_restart=0
	if [ -e /customer/blestate ]
	then		
		tmp_ble_state=$(cat /customer/blestate)
		tmp_ble_state_update_time=$(stat -c %Y /customer/blestate)
		if [ "$tmp_ble_state" != "" ] && [ "$tmp_ble_state" != "2" ] && [ "$tmp_ble_state" != "0" ] && [ "$tmp_ble_state" == "$ble_state" ] && [ "$tmp_ble_state_update_time" == "$ble_state_update_time" ]
		then
			ble_state_count=$(($ble_state_count+1))
			if [ "$tmp_ble_state" == "5" ]
			then
				if [ "$ble_state_count" == "360" ]
				then
					ble_need_restart=1
				fi
			else
				if [ "$ble_state_count" == "40" ]
				then
					ble_need_restart=1
				fi
			fi
		else
			ble_state=$tmp_ble_state
			ble_state_update_time=$tmp_ble_state_update_time
			ble_state_count=0;
		fi
		
		if [ "`pidof rtl_gatts`" != "" ] && [ "$tmp_ble_state" == "2" ]
		then
			ble_adv_count=$(($ble_adv_count+1))
			if [ "$ble_adv_count" == "12" ]
			then
				ble_adv_count=0
				/software/enable_ble_adv.sh &
			fi
		else
			ble_adv_count=0;
		fi
	fi
	
	if [ "$ble_need_restart" == "1"  ]
	then
		ble_state_count=0;
		echo > /customer/blestate
		if [ ! `pidof rtl_gatts` ]
		then			
			/software/restart_bluetooth.sh notip &
		else
			/software/disconnect_ble.sh &
		fi
	fi
	
	
	
	if [ "`pidof JpegPlayer`" != "" ] && [ "`grep off /customer/screen_on_off`" == ""  ] && [ ! `pidof showGrayPicture` ] && [ ! `pgrep -f showGrayPicture.sh` ]
    then
		filename="/customer/config.ini"
		section="screen"
		key="display_type"
		display_mode_key="display_mode"

		value=$(awk -F "=" -v section="$section" -v key="$key" '$1 ~ /^\[/ && $1 ~ section {flag=1; next} flag==1 && $1 ~ /^\[/ {flag=0} flag==1 && $1 ~ key {print $2}' "$filename")
		display_mode=$(awk -F "=" -v section="$section" -v key="$display_mode_key" '$1 ~ /^\[/ && $1 ~ section {flag=1; next} flag==1 && $1 ~ /^\[/ {flag=0} flag==1 && $1 ~ key {print $2}' "$filename")
		
		if [ "${currentProcess}" == "0" ]
		then
			currentProcess=$value
		fi
		
		if [ "${value}" == "3" ]
		then
			if [ "${value}" == "${currentProcess}" ] && [ ! `pidof clock` ]
			then
				processDownCount=$(($processDownCount+1))
			else
				currentProcess=$value
				processDownCount=0
			fi
			
			if [ "${processDownCount}" -eq "6" ]
			then			
				/software/restart_clock.sh &
			fi
		elif [ "${value}" == "4" ]
		then
			if [ "${value}" == "${currentProcess}" ] && [ ! `pidof calander` ]
			then
				processDownCount=$(($processDownCount+1))
			else
				currentProcess=$value
				processDownCount=0
			fi
			
			if [ "${processDownCount}" -eq "6" ]
			then			
				/software/restart_calender.sh &
			fi
		elif [ "${value}" == "5" ]
		then
			if [ "${value}" == "${currentProcess}" ] && [ ! `pidof showNumber` ]
			then
				processDownCount=$(($processDownCount+1))
			else
				currentProcess=$value
				processDownCount=0
			fi
			
			if [ "${processDownCount}" -eq "6" ]
			then			
				/software/restart_show_number.sh &
			fi			
		else		
			if [ "${value}" == "${currentProcess}" ] && [ "${display_mode}" != "7" ] && [ "${display_mode}" != "8" ] && [ ! `pidof demo` ]
			then
				processDownCount=$(($processDownCount+1))
			else
				currentProcess=$value
				processDownCount=0
			fi
			
			if [ "${processDownCount}" -eq "6" ] || [ -e /software/restart_pintura_flag ]
			then	
				if [ -e /software/restart_pintura_flag ]; then
					rm /software/restart_pintura_flag;
				fi
				/software/restart_pintura.sh &
			fi			
		fi
	fi
	
    if [ ! `pidof mymqtt` ] && [ "`ifconfig | grep 'inet addr:'`" != "" ] && [ `cat /sys/class/net/wlan0/operstate | grep up` ]
    then
	   if [ ! -e /customer/pairing_status ] || [ `cat /customer/pairing_status | grep success` ]
	   then
			wlanHasUp=1
			/software/mqtt/mymqtt &
			kill -9 $(pidof ntpd)
			
			filename="/software/local.ini"
			section="local"
			key="local"

			value=$(awk -F "=" -v section="$section" -v key="$key" '$1 ~ /^\[/ && $1 ~ section {flag=1; next} flag==1 && $1 ~ /^\[/ {flag=0} flag==1 && $1 ~ key {print $2}' "$filename")
			if [ "${value}" == "1" ]; then
				echo "ntpd -p ntp.aliyun.com"
				ntpd -p ntp.aliyun.com &
			else
				echo "ntpd -p time.nist.gov"
				ntpd -p time.nist.gov &
			fi
	   fi
    fi
	
	if [ ! -e /sys/class/gpio/gpio71/value ]
	then
		#reset gpio, cat /sys/class/gpio/gpio71/value 1:normal 0: press
		echo 71 > /sys/class/gpio/export
	fi
	
	if [ `cat /sys/class/gpio/gpio71/value | grep 0` ]
	then
		pressTimeCount=$(($pressTimeCount+1))
		
		if [ "$pressTimeCount" -eq "1" ]
		then
			filesize=`ls -l $logName |awk '{print $5}'`
			if [ "$filesize" -ge "$maxsize" ]
			then
				echo > $logName
			fi
			printTime=$(date +%Y%m%d-%H:%M:%S)
			echo -e "$printTime short press restart bluetooth \n" >> $logName
			echo "short press restart bluetooth"
			/software/restart_bluetooth.sh &
		fi
		
		if [ "$pressTimeCount" -eq "20" ]
		then
			echo "system_reset_tip" > /upgrade/reset_status
		fi
		
		if [ "$pressTimeCount" -eq "40" ]
		then
			filesize=`ls -l $logName |awk '{print $5}'`
			if [ "$filesize" -ge "$maxsize" ]
			then
				echo > $logName				
			fi
			printTime=$(date +%Y%m%d-%H:%M:%S)
			echo -e "$printTime long press recover system \n" >> $logName
			echo "long press recover system"
			/upgrade/restore_factory_settings.sh &
		fi
					
	else
		
		pressTimeCount=0
	fi
		
    sleep 0.25
done
