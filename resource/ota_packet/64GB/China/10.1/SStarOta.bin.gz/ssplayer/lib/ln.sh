current_path=$(pwd)
cd $current_path

if [ -f "$current_path/libavcodec.so" ] && [ ! -f "$current_path/libavcodec.so.58" ]; then
	ln -s libavcodec.so libavcodec.so.58
fi

if [ -f "$current_path/libavformat.so" ] && [ ! -f "$current_path/libavformat.so.58" ]; then
	ln -s libavformat.so libavformat.so.58
fi

if [ -f "$current_path/libavutil.so" ] && [ ! -f "$current_path/libavutil.so.56" ]; then
	ln -s libavutil.so libavutil.so.56
fi

if [ -f "$current_path/libswresample.so" ] && [ ! -f "$current_path/libswresample.so.3" ]; then
	ln -s libswresample.so libswresample.so.3
fi

if [ -f "$current_path/libswscale.so" ] && [ ! -f "$current_path/libswscale.so.5" ]; then
	ln -s libswscale.so libswscale.so.5
fi