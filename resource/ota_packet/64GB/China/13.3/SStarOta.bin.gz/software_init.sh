mount -t vfat /dev/mmcblk0p1 /mnt

mkdir -p /customer/picture/
mkdir -p /customer/picture_cache/
mkdir -p /customer/video/
mkdir -p /customer/video_cache/

if mountpoint -q "/mnt"; then 
	mkdir -p /mnt/picture/
	mkdir -p /mnt/video/
	if [ -s /mnt/init.sh ]
	then
		chmod +x /mnt/init.sh
		/mnt/init.sh &
	fi
else
	if [ -s /customer/mnt_config.ini_bak ]
	then
		mv -f /customer/mnt_config.ini_bak /customer/config.ini 
	fi

	if [ -s /customer/mnt_video_config.ini_bak ]
	then
		mv -f /customer/mnt_video_config.ini_bak /customer/video_config.ini 
	fi
fi

if [ -f /software/ssplayer/lib/ln.sh ]; then
	cd /software/ssplayer/lib/
	./ln.sh &
fi

if [ -e /software/show_video_logo ]; then
rm /software/show_video_logo
fi

export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/lib:/config/lib:/customer/bluetooth/lib:/software/bluetooth/lib:/software/JpegPlayer/lib:/upgrade/JpegPlayer/lib:/config/wifi:/software/qrcode:/software/mqtt

cd /software/

if ([ ! -e /customer/config.ini ] || [ "$(cat /customer/config.ini)" == "" ]) && [ -e /customer/config.ini_bak ] && [ "$(cat /customer/config.ini_bak)" != "" ]
then
	cp /customer/config.ini_bak /customer/config.ini
fi

if ([ ! -e /customer/luma_config.ini ] || [ "$(cat /customer/luma_config.ini)" == "" ]) && [ -e /customer/luma_config.ini_bak ] && [ "$(cat /customer/luma_config.ini_bak)" != "" ]
then
	cp /customer/luma_config.ini_bak /customer/luma_config.ini
fi

if ([ ! -e /customer/color_temper_config.ini ] || [ "$(cat /customer/color_temper_config.ini)" == "" ]) && [ -e /customer/color_temper_config.ini_bak ] && [ "$(cat /customer/color_temper_config.ini_bak)" != "" ]
then
	cp /customer/color_temper_config.ini_bak /customer/color_temper_config.ini
fi



if [ -e /software/upgrade.sh ]; then
	if [ ! -e /upgrade/upgrade.sh ]; then
		if grep -q $(md5sum upgrade.sh) software_md5; then
			cp /software/upgrade.sh /upgrade/
		fi 
	else
		if ! diff /software/upgrade.sh /upgrade/upgrade.sh >/dev/null; then
			if grep -q $(md5sum upgrade.sh) software_md5; then
				cp /software/upgrade.sh /upgrade/
			fi    
		fi
	fi
fi;

if [ -e /software/daemon.sh ]; then
	if [ ! -e /upgrade/daemon.sh ]; then 
		if grep -q $(md5sum daemon.sh) software_md5; then
			cp /software/daemon.sh /upgrade/
			sleep 1;
			if [ `pgrep -f daemon.sh` ]; then
				kill -9 $(pgrep -f daemon.sh);
				sleep 1;
			fi
			if [ ! `pgrep -f daemon.sh` ]; then
				/upgrade/daemon.sh &
			fi
		fi
	else
		if ! diff /software/daemon.sh /upgrade/daemon.sh >/dev/null; then   
			if grep -q $(md5sum daemon.sh) software_md5; then
				cp /software/daemon.sh /upgrade/	
				sleep 1;
				if [ `pgrep -f daemon.sh` ]; then
					kill -9 $(pgrep -f daemon.sh);
					sleep 1;
				fi
				if [ ! `pgrep -f daemon.sh` ]; then
					/upgrade/daemon.sh &
				fi
			fi
		fi;
	fi
fi;

if [ -e /software/restore_factory_settings.sh ]; then
	if [ ! -e /upgrade/restore_factory_settings.sh ]; then
		if grep -q $(md5sum restore_factory_settings.sh) software_md5; then
			cp /software/restore_factory_settings.sh /upgrade/
		fi
	else
		if ! diff /software/restore_factory_settings.sh /upgrade/restore_factory_settings.sh >/dev/null; then
			if grep -q $(md5sum restore_factory_settings.sh) software_md5; then
				cp /software/restore_factory_settings.sh /upgrade/
			fi
		fi
	fi
fi;

filename="/software/local.ini"
section="local"
key="local"

value=$(awk -F "=" -v section="$section" -v key="$key" '$1 ~ /^\[/ && $1 ~ section {flag=1; next} flag==1 && $1 ~ /^\[/ {flag=0} flag==1 && $1 ~ key {print $2}' "$filename")
if [ "${value}" == "2" ]; then
	if [ -e /software/resolv.conf ]; then
		if ! diff /software/resolv.conf /customer/resolv.conf >/dev/null; then
			if  grep -q $(md5sum resolv.conf) software_md5; then
				cp /software/resolv.conf /customer/
			fi
		fi
	fi;
elif [ "${value}" == "1" ]; then
	if [ -e /software/resolv.conf_cn ]; then
		if ! diff /software/resolv.conf_cn /customer/resolv.conf >/dev/null; then
			if  grep -q $(md5sum resolv.conf_cn) software_md5; then
				cp /software/resolv.conf_cn /customer/resolv.conf
			fi
		fi
	fi;
fi

if [ -e /software/ota_launcher ]; then
	if [ ! -e /upgrade/ota_launcher ]; then
		if grep -q $(md5sum ota_launcher) software_md5; then
			cp /software/ota_launcher /upgrade/
		fi
	else
		if ! diff /software/ota_launcher /upgrade/ota_launcher >/dev/null; then
			if grep -q $(md5sum ota_launcher) software_md5; then
				cp /software/ota_launcher /upgrade/
			fi
		fi
	fi
fi;

if [ -e /software/JpegPlayer ] && [ ! -e /upgrade/JpegPlayer ]; then	
	cp -rf /software/JpegPlayer /upgrade/	
fi;

if [ -e /software/JpegPlayer/JpegPlayer ]; then	
	if ! diff /software/JpegPlayer/JpegPlayer /upgrade/JpegPlayer/JpegPlayer >/dev/null; then
		cp  /software/JpegPlayer/JpegPlayer /upgrade/JpegPlayer/	
	fi
fi;

if [ -e /software/ota_view ] && [ ! -e /upgrade/ota_view ]; then	
	cp -rf /software/ota_view /upgrade/	
fi;

if [ -e /software/restart_ota_down_view.sh ] ; then	
	if [ ! -e /upgrade/restart_ota_down_view.sh ]; then
		if grep -q $(md5sum restart_ota_down_view.sh) software_md5; then
			cp  /software/restart_ota_down_view.sh /upgrade/
		fi;
	else
		if ! diff /software/restart_ota_down_view.sh /upgrade/restart_ota_down_view.sh >/dev/null; then
			if grep -q $(md5sum restart_ota_down_view.sh) software_md5; then
				cp  /software/restart_ota_down_view.sh /upgrade/
			fi;
		fi
	fi
fi;

if [ -e /software/restart_reset_view.sh ] ; then	
	if [ ! -e /upgrade/restart_reset_view.sh ]; then
		if grep -q $(md5sum restart_reset_view.sh) software_md5; then
			cp  /software/restart_reset_view.sh /upgrade/
		fi;
	else
		if ! diff /software/restart_reset_view.sh /upgrade/restart_reset_view.sh >/dev/null; then
			if grep -q $(md5sum restart_reset_view.sh) software_md5; then
				cp  /software/restart_reset_view.sh /upgrade/
			fi;
		fi
	fi
fi;

if [ -e /software/ota_view/release/bin/ota_download ]; then	
	if [ ! -e /upgrade/ota_view/release/bin/ota_download ]; then 
		if grep -q $(md5sum ota_view/release/bin/ota_download) software_md5; then
			cp  /software/ota_view/release/bin/ota_download /upgrade/ota_view/release/bin/
		fi;
	else
		if ! diff /software/restart_reset_view.sh /upgrade/restart_reset_view.sh >/dev/null; then		
			if grep -q $(md5sum ota_view/release/bin/ota_download) software_md5; then
				cp  /software/ota_view/release/bin/ota_download /upgrade/ota_view/release/bin/
			fi;
		fi;
	fi
fi;

if [ -e /software/ota_view/release/bin/reset_view ]; then	
	if [ ! -e /upgrade/ota_view/release/bin/reset_view ]; then 
		if grep -q $(md5sum ota_view/release/bin/reset_view) software_md5; then
			cp  /software/ota_view/release/bin/reset_view /upgrade/ota_view/release/bin/
		fi;
	else		
		if ! diff /software/ota_view/release/bin/reset_view /upgrade/ota_view/release/bin/reset_view >/dev/null; then
			if grep -q $(md5sum ota_view/release/bin/reset_view) software_md5; then
				cp  /software/ota_view/release/bin/reset_view /upgrade/ota_view/release/bin/
			fi;
		fi;
	fi
fi;

if [ -e /software/ota_view/release/assets/default/raw/ui/ota_download_page.bin ]; then	
	if [ ! -e /upgrade/ota_view/release/assets/default/raw/ui/ota_download_page.bin ]; then 
		if grep -q $(md5sum ota_view/release/assets/default/raw/ui/ota_download_page.bin) software_md5; then
				cp  /software/ota_view/release/assets/default/raw/ui/ota_download_page.bin /upgrade/ota_view/release/assets/default/raw/ui/
		fi;
	else
		if ! diff /software/ota_view/release/assets/default/raw/ui/ota_download_page.bin /upgrade/ota_view/release/assets/default/raw/ui/ota_download_page.bin >/dev/null; then
			if grep -q $(md5sum ota_view/release/assets/default/raw/ui/ota_download_page.bin) software_md5; then
				cp  /software/ota_view/release/assets/default/raw/ui/ota_download_page.bin /upgrade/ota_view/release/assets/default/raw/ui/
			fi;
		fi;
	fi
fi;

if [ -e /software/ota_view/release/assets/default/raw/ui/reset_view_page.bin ]; then	
	if [ ! -e /upgrade/ota_view/release/assets/default/raw/ui/reset_view_page.bin ]; then 
		if grep -q $(md5sum ota_view/release/assets/default/raw/ui/reset_view_page.bin) software_md5; then
				cp  /software/ota_view/release/assets/default/raw/ui/reset_view_page.bin /upgrade/ota_view/release/assets/default/raw/ui/
		fi;
	else		 
		if ! diff /software/ota_view/release/assets/default/raw/ui/reset_view_page.bin /upgrade/ota_view/release/assets/default/raw/ui/reset_view_page.bin >/dev/null; then
			if grep -q $(md5sum ota_view/release/assets/default/raw/ui/reset_view_page.bin) software_md5; then
				cp  /software/ota_view/release/assets/default/raw/ui/reset_view_page.bin /upgrade/ota_view/release/assets/default/raw/ui/
			fi;
		fi;
	fi
fi;

if [ -e /software/ota_view/release/assets/default/raw/styles/ota_download_page.bin ]; then	
	if [ ! -e /upgrade/ota_view/release/assets/default/raw/styles/ota_download_page.bin ]; then 
		if grep -q $(md5sum ota_view/release/assets/default/raw/styles/ota_download_page.bin) software_md5; then
				cp  /software/ota_view/release/assets/default/raw/styles/ota_download_page.bin /upgrade/ota_view/release/assets/default/raw/styles/
		fi;
	else
		if ! diff /software/ota_view/release/assets/default/raw/styles/ota_download_page.bin /upgrade/ota_view/release/assets/default/raw/styles/ota_download_page.bin >/dev/null; then
			if grep -q $(md5sum ota_view/release/assets/default/raw/styles/ota_download_page.bin) software_md5; then
				cp  /software/ota_view/release/assets/default/raw/styles/ota_download_page.bin /upgrade/ota_view/release/assets/default/raw/styles/
			fi;
		fi;
	fi
fi;

if [ -e /software/ota_view/release/assets/default/raw/styles/reset_view_page.bin ]; then	
	if [ ! -e /upgrade/ota_view/release/assets/default/raw/styles/reset_view_page.bin ]; then 
		if grep -q $(md5sum ota_view/release/assets/default/raw/styles/reset_view_page.bin) software_md5; then
				cp  /software/ota_view/release/assets/default/raw/styles/reset_view_page.bin /upgrade/ota_view/release/assets/default/raw/styles/
		fi;
	else
		if ! diff /software/ota_view/release/assets/default/raw/styles/reset_view_page.bin /upgrade/ota_view/release/assets/default/raw/styles/reset_view_page.bin >/dev/null; then
			if grep -q $(md5sum ota_view/release/assets/default/raw/styles/reset_view_page.bin) software_md5; then
				cp  /software/ota_view/release/assets/default/raw/styles/reset_view_page.bin /upgrade/ota_view/release/assets/default/raw/styles/
			fi;
		fi;
	fi
fi;

if [ -e /software/ota_view/release/assets/default/raw/strings/en_US.bin ]; then	
	if [ ! -e /upgrade/ota_view/release/assets/default/raw/strings/en_US.bin ]; then 
		if grep -q $(md5sum ota_view/release/assets/default/raw/strings/en_US.bin) software_md5; then
				cp  /software/ota_view/release/assets/default/raw/strings/en_US.bin /upgrade/ota_view/release/assets/default/raw/strings/
		fi;
	else
		if ! diff /software/ota_view/release/assets/default/raw/strings/en_US.bin /upgrade/ota_view/release/assets/default/raw/strings/en_US.bin >/dev/null; then
			if grep -q $(md5sum ota_view/release/assets/default/raw/strings/en_US.bin) software_md5; then
				cp  /software/ota_view/release/assets/default/raw/strings/en_US.bin /upgrade/ota_view/release/assets/default/raw/strings/
			fi;
		fi;
	fi
fi;

if [ -e /software/ota_view/release/assets/default/raw/strings/zh_CN.bin ]; then	
	if [ ! -e /upgrade/ota_view/release/assets/default/raw/strings/zh_CN.bin ]; then 
		if grep -q $(md5sum ota_view/release/assets/default/raw/strings/zh_CN.bin) software_md5; then
				cp  /software/ota_view/release/assets/default/raw/strings/zh_CN.bin /upgrade/ota_view/release/assets/default/raw/strings/
		fi;
	else
		if ! diff /software/ota_view/release/assets/default/raw/strings/zh_CN.bin /upgrade/ota_view/release/assets/default/raw/strings/zh_CN.bin >/dev/null; then
			if grep -q $(md5sum ota_view/release/assets/default/raw/strings/zh_CN.bin) software_md5; then
				cp  /software/ota_view/release/assets/default/raw/strings/zh_CN.bin /upgrade/ota_view/release/assets/default/raw/strings/
			fi;
		fi;
	fi
fi;

if [ -e /software/local.ini ]; then	
	if [ ! -e /upgrade/local.ini ]; then 
		if grep -q $(md5sum local.ini) software_md5; then
			cp  /software/local.ini /upgrade/
		fi;
	else
		if ! diff /software/local.ini /upgrade/local.ini >/dev/null; then
			if grep -q $(md5sum local.ini) software_md5; then
				cp  /software/local.ini /upgrade/
			fi;
		fi;
	fi
fi;

if [ -e /software/volume.ini ]; then	
	if [ ! -e /customer/volume.ini ]; then 
		if grep -q $(md5sum volume.ini) software_md5; then
			
			cp  /software/volume.ini /customer/
			rm  /software/volume.ini
		fi;
	else
		if ! diff /software/volume.ini /customer/volume.ini >/dev/null; then
			if grep -q $(md5sum volume.ini) software_md5; then
				cp  /software/volume.ini /customer/
				rm  /software/volume.ini
			fi;
		fi;
	fi
fi;

echo '' > /upgrade/ota_status
echo '' > /upgrade/reset_status
echo 'on' > /customer/screen_on_off


rm /config/coredump.process_*
/config/wifi/ssw01bInit.sh
/config/wifi/restart_wifi.sh &
mkdir /var/run
mount tmpfs /var/run -t tmpfs
ln -s /customer/bluetooth/bluez_build/dbus/var/run/dbus /var/run/dbus
rm /customer/bluetooth/bluez_build/dbus/var/run/dbus/pid
insmod /customer/bluetooth/rtk_btusb.ko
cd /customer/bluetooth/bin
./dbus-daemon --system &
./bluetoothd -n -C &

sleep 1
cd /software/
./check_usb.sh &
./check_sdcard.sh &
./launcher &
./picture_downloader &




cd /software/white_balance/
./uart_main &



#cd /software/qrcode
#./myqrcode &
#if [ -e /software/qrcode/qrcode.png ]; then
#	cp /software/qrcode/qrcode.png /customer/picture/
#fi

#schedule sleep wakeup
mkdir -p /var/spool/cron/crontabs
mkdir -p /etc/crontabs/
if [ -e /etc/crontabs/root ]; then
	cp -p /etc/crontabs/root /var/spool/cron/crontabs
	chmod 777 /var/spool/cron/crontabs/root
fi
crond

sync
