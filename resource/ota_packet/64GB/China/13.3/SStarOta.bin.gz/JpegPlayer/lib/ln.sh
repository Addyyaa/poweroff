current_path=$(pwd)
cd $current_path

if [ -f "$current_path/libjpeg.so" ] && [ ! -f "$current_path/libjpeg.so.7" ]; then
	ln -s libjpeg.so libjpeg.so.7
fi

if [ -f "$current_path/libjpeg.so" ] && [ ! -f "$current_path/libjpeg.so.7.0.0" ]; then
	ln -s libjpeg.so libjpeg.so.7.0.0
fi

if [ -f "$current_path/libz.so" ] && [ ! -f "$current_path/libz.so.1" ]; then
	ln -s libz.so libz.so.1
fi

if [ -f "$current_path/libz.so" ] && [ ! -f "$current_path/libz.so.1.2.2" ]; then
	ln -s libz.so libz.so.1.2.2
fi