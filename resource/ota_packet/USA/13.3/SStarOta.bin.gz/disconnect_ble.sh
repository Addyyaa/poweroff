cd /customer/bluetooth/bin
handle=$(./hcitool con | grep -o 'handle [0-9]\+' | awk '{print $2}')
if [ "$handle" != "" ]
then
./hcitool ledc $handle
./hciconfig hci0 leadv
else
/software/restart_bluetooth.sh notip &
fi
